Thank you for downloading my Image editor.
This program will be flagged as "harmful" or as a virus.
if this happens simple allow it to run anyway.
Source code is in the main folder.